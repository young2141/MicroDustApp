-- #1 : employee fname,lname index
create index employee_first_last_name_idx on employee(fname, lname);
select * from EMPLOYEE EMP where EMP.fname = 'John' AND EMP.lname = 'Smith';

-- #2 : dept index
create index dept_dname_mgrssn_idx on department(dname, mgr_ssn);
select * from DEPARTMENT where dname = 'Administration' AND to_number(mgr_ssn) = 987654321;

-- #3
select index_name, table_name, column_name
from USER_IND_COLUMNS
where table_name = 'PROJECT';
-- 3) index names : SYS_C007463, SYS_C007464
-- 3) used column : (1) SYS_C007463 : Pnumber  | (2) SYS_C007464 : Pname

-- #4
select index_name, table_name
from USER_INDEXES
where table_name in ('WORKS_ON', 'DEPT_LOCATIONS');
-- 4) # of indexes for WORKS_ON : 1, for DEPT_LOCATIONS : 1

-- #5
create index dep_relation_idx on dependent(relationship);
select * from dependent where essn = '333445555' AND relationship =  'Son';
-- 5) index is used.